export type FileType = 'file' | 'dir';

export interface VFSNode {
    type: FileType;
    name: string;
    content?: string; // For files
    children?: Record<string, VFSNode>; // For directories
    createdAt: number;
}

export interface HistoryEntry {
    id: string;
    type: 'input' | 'output' | 'error' | 'system';
    content: React.ReactNode | string;
    path?: string; // Path at the time of execution
}

export interface CommandContext {
    args: string[];
    rawCommand: string;
    currentPath: string;
    vfs: VFSNode;
    setVfs: React.Dispatch<React.SetStateAction<VFSNode>>;
    setCurrentPath: React.Dispatch<React.SetStateAction<string>>;
    print: (content: React.ReactNode | string, type?: HistoryEntry['type']) => void;
    clear: () => void;
    env: Record<string, string>;
    setEnv: React.Dispatch<React.SetStateAction<Record<string, string>>>;
    commandHistory: string[];
}
