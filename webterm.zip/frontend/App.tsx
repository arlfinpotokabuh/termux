import React, { useState, useRef, useEffect } from 'react';
import { useTerminal } from './hooks/useTerminal';
import { TerminalOutput } from './components/TerminalOutput';
import { Terminal as TerminalIcon, LayoutTemplate } from 'lucide-react';
import { resolvePath, getNodeAtPath } from './utils/vfs';

const App: React.FC = () => {
    const { history, currentPath, env, vfs, execute, navigateHistory } = useTerminal();
    const [activeTab, setActiveTab] = useState<'terminal' | 'preview'>('terminal');
    const [inputValue, setInputValue] = useState('');
    const inputRef = useRef<HTMLInputElement>(null);
    const bottomRef = useRef<HTMLDivElement>(null);
    const containerRef = useRef<HTMLDivElement>(null);

    // Format path for prompt display (replace HOME with ~)
    const displayPath = currentPath.startsWith(env.HOME) 
        ? currentPath.replace(env.HOME, '~') 
        : currentPath;

    useEffect(() => {
        if (activeTab === 'terminal') {
            bottomRef.current?.scrollIntoView({ behavior: 'auto' });
            inputRef.current?.focus();
        }
    }, [history, activeTab]);

    const handleContainerClick = () => {
        if (activeTab === 'terminal') {
            inputRef.current?.focus();
        }
    };

    const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
        if (e.key === 'Enter') {
            execute(inputValue);
            setInputValue('');
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            const prevCmd = navigateHistory('up');
            if (prevCmd !== null) setInputValue(prevCmd);
        } else if (e.key === 'ArrowDown') {
            e.preventDefault();
            const nextCmd = navigateHistory('down');
            if (nextCmd !== null) setInputValue(nextCmd);
        } else if (e.key === 'c' && e.ctrlKey) {
            e.preventDefault();
            execute('^C');
            setInputValue('');
        } else if (e.key === 'z' && e.ctrlKey) {
            e.preventDefault();
            execute('^Z');
            setInputValue('');
        } else if (e.key === 'l' && e.ctrlKey) {
            e.preventDefault();
            execute('clear');
        }
    };

    // Preview Logic: Look for index.html in the current directory
    const getPreviewContent = () => {
        const indexPath = resolvePath(currentPath, 'index.html');
        const node = getNodeAtPath(vfs, indexPath);
        if (node && node.type === 'file') {
            return node.content || '';
        }
        return null;
    };

    const previewContent = getPreviewContent();

    return (
        <div className="h-screen w-screen bg-term-bg text-term-fg font-mono text-sm sm:text-base flex flex-col overflow-hidden">
            {/* Tab Bar */}
            <div className="flex bg-[#252526] border-b border-black shrink-0">
                <button
                    className={`px-4 py-2 flex items-center gap-2 transition-colors ${
                        activeTab === 'terminal' 
                            ? 'bg-[#1e1e1e] border-t-2 border-t-term-prompt text-white' 
                            : 'text-gray-400 hover:bg-[#2d2d2d] border-t-2 border-transparent'
                    }`}
                    onClick={() => setActiveTab('terminal')}
                >
                    <TerminalIcon size={16} /> Terminal
                </button>
                <button
                    className={`px-4 py-2 flex items-center gap-2 transition-colors ${
                        activeTab === 'preview' 
                            ? 'bg-[#1e1e1e] border-t-2 border-t-term-prompt text-white' 
                            : 'text-gray-400 hover:bg-[#2d2d2d] border-t-2 border-transparent'
                    }`}
                    onClick={() => setActiveTab('preview')}
                >
                    <LayoutTemplate size={16} /> Preview
                </button>
            </div>

            {/* Content Area */}
            <div className="flex-1 relative">
                {/* Terminal Panel */}
                <div 
                    ref={containerRef}
                    className={`absolute inset-0 p-2 sm:p-4 flex flex-col overflow-y-auto overflow-x-hidden transition-opacity duration-200 ${
                        activeTab === 'terminal' ? 'z-10 opacity-100' : 'z-0 opacity-0 pointer-events-none'
                    }`}
                    onClick={handleContainerClick}
                >
                    {history.map((entry) => (
                        <TerminalOutput key={entry.id} entry={entry} />
                    ))}
                    
                    <div className="flex items-start mt-1">
                        <span className="text-term-prompt font-bold mr-2 shrink-0">
                            ~ $
                        </span>
                        <input
                            ref={inputRef}
                            type="text"
                            value={inputValue}
                            onChange={(e) => setInputValue(e.target.value)}
                            onKeyDown={handleKeyDown}
                            className="flex-1 bg-transparent outline-none border-none text-term-fg caret-term-fg"
                            autoFocus
                            spellCheck={false}
                            autoComplete="off"
                            autoCorrect="off"
                            autoCapitalize="off"
                            tabIndex={activeTab === 'terminal' ? 0 : -1}
                        />
                    </div>
                    <div ref={bottomRef} className="h-4 shrink-0" />
                </div>

                {/* Preview Panel */}
                <div className={`absolute inset-0 bg-white transition-opacity duration-200 ${
                    activeTab === 'preview' ? 'z-10 opacity-100' : 'z-0 opacity-0 pointer-events-none'
                }`}>
                    {previewContent !== null ? (
                        <iframe
                            srcDoc={previewContent}
                            className="w-full h-full border-none"
                            title="Preview"
                            sandbox="allow-scripts allow-same-origin"
                        />
                    ) : (
                        <div className="flex flex-col items-center justify-center h-full text-gray-400 bg-[#1e1e1e]">
                            <LayoutTemplate size={48} className="mb-4 opacity-50" />
                            <p className="text-lg">No <code>index.html</code> found in current directory.</p>
                            <div className="mt-6 p-4 bg-black/30 rounded-lg border border-gray-800 text-sm">
                                <p className="mb-2 text-gray-300">Try running this command in the terminal:</p>
                                <code className="text-term-prompt select-all">
                                    echo "&lt;h1&gt;Hello from Termux!&lt;/h1&gt;" &gt; index.html
                                </code>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default App;
