import React from 'react';
import { HistoryEntry } from '../types';

interface TerminalOutputProps {
    entry: HistoryEntry;
}

export const TerminalOutput: React.FC<TerminalOutputProps> = ({ entry }) => {
    if (entry.type === 'input') {
        return (
            <div className="flex items-start mb-1">
                <span className="text-term-prompt font-bold mr-2 shrink-0">~ $</span>
                <span className="text-term-fg break-all">{entry.content}</span>
            </div>
        );
    }

    let contentClass = 'text-term-fg';
    if (entry.type === 'error') contentClass = 'text-term-error';
    if (entry.type === 'system') contentClass = 'text-term-highlight';

    if (typeof entry.content === 'object' && entry.content !== null && '__html' in entry.content) {
        return (
            <div 
                className={`mb-1 whitespace-pre-wrap break-all ${contentClass}`}
                dangerouslySetInnerHTML={entry.content as { __html: string }}
            />
        );
    }

    return (
        <div className={`mb-1 whitespace-pre-wrap break-all ${contentClass}`}>
            {entry.content}
        </div>
    );
};
