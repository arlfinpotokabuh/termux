import { VFSNode } from '../types';

// Expanded Initial File System State (Termux-like)
export const initialVFS: VFSNode = {
    type: 'dir',
    name: 'root',
    createdAt: Date.now(),
    children: {
        'data': {
            type: 'dir',
            name: 'data',
            createdAt: Date.now(),
            children: {
                'data': {
                    type: 'dir',
                    name: 'data',
                    createdAt: Date.now(),
                    children: {
                        'com.termux': {
                            type: 'dir',
                            name: 'com.termux',
                            createdAt: Date.now(),
                            children: {
                                'files': {
                                    type: 'dir',
                                    name: 'files',
                                    createdAt: Date.now(),
                                    children: {
                                        'home': {
                                            type: 'dir',
                                            name: 'home',
                                            createdAt: Date.now(),
                                            children: {
                                                'readme.txt': {
                                                    type: 'file',
                                                    name: 'readme.txt',
                                                    content: 'Welcome to WebTerm (Termux Edition)!\nThis is a standalone HTML5 terminal emulator.\nTry typing "help", "neofetch", "pkg install python", or "curl".',
                                                    createdAt: Date.now(),
                                                }
                                            }
                                        },
                                        'usr': {
                                            type: 'dir',
                                            name: 'usr',
                                            createdAt: Date.now(),
                                            children: {
                                                'bin': { type: 'dir', name: 'bin', createdAt: Date.now(), children: {} },
                                                'etc': { type: 'dir', name: 'etc', createdAt: Date.now(), children: {} },
                                                'lib': { type: 'dir', name: 'lib', createdAt: Date.now(), children: {} }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        'system': {
            type: 'dir',
            name: 'system',
            createdAt: Date.now(),
            children: {
                'bin': { type: 'dir', name: 'bin', createdAt: Date.now(), children: {} },
                'etc': { type: 'dir', name: 'etc', createdAt: Date.now(), children: {} }
            }
        }
    }
};

// Normalize path (handle ., .., and multiple slashes)
export const normalizePath = (path: string): string => {
    const parts = path.split('/').filter(p => p !== '' && p !== '.');
    const resolved: string[] = [];
    
    for (const part of parts) {
        if (part === '..') {
            if (resolved.length > 0) resolved.pop();
        } else {
            resolved.push(part);
        }
    }
    
    return '/' + resolved.join('/');
};

// Resolve absolute path from current path and target
export const resolvePath = (currentPath: string, targetPath: string): string => {
    if (targetPath.startsWith('/')) {
        return normalizePath(targetPath);
    }
    return normalizePath(`${currentPath}/${targetPath}`);
};

// Get a node from the VFS by absolute path
export const getNodeAtPath = (vfs: VFSNode, path: string): VFSNode | null => {
    if (path === '/') return vfs;
    
    const parts = path.split('/').filter(p => p !== '');
    let current: VFSNode | undefined = vfs;
    
    for (const part of parts) {
        if (current?.type !== 'dir' || !current.children) return null;
        current = current.children[part];
        if (!current) return null;
    }
    
    return current || null;
};

// Deep clone VFS to avoid direct state mutation issues
export const cloneVFS = (vfs: VFSNode): VFSNode => {
    return JSON.parse(JSON.stringify(vfs));
};

// Helper to write a file
export const writeFile = (vfs: VFSNode, path: string, content: string): boolean => {
    const parentPath = resolvePath(path, '..');
    const fileName = path.split('/').pop();
    if (!fileName) return false;

    const parentNode = getNodeAtPath(vfs, parentPath);
    if (!parentNode || parentNode.type !== 'dir') return false;

    if (!parentNode.children) parentNode.children = {};
    parentNode.children[fileName] = {
        type: 'file',
        name: fileName,
        content,
        createdAt: Date.now()
    };
    return true;
};
