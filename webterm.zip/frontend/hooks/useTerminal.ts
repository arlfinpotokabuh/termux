import { useState, useCallback } from 'react';
import { HistoryEntry, VFSNode } from '../types';
import { initialVFS } from '../utils/vfs';
import { executeCommand } from '../commands/index';

const generateId = () => Math.random().toString(36).substring(2, 9);

export const useTerminal = () => {
    const [history, setHistory] = useState<HistoryEntry[]>([
        {
            id: generateId(),
            type: 'system',
            content: 'Welcome to Termux!\n\nWiki:            https://wiki.termux.com\nCommunity forum: https://termux.com/community\n\nWorking with packages:\n * Search packages:   pkg search <query>\n * Install a package: pkg install <package>\n * Upgrade packages:  pkg upgrade\n\nType "help" for a list of built-in commands.'
        }
    ]);
    
    const [env, setEnv] = useState<Record<string, string>>({
        USER: 'u0_a123',
        HOME: '/data/data/com.termux/files/home',
        PREFIX: '/data/data/com.termux/files/usr',
        SHELL: '/data/data/com.termux/files/usr/bin/bash',
        TERM: 'xterm-256color',
        PATH: '/data/data/com.termux/files/usr/bin'
    });

    const [currentPath, setCurrentPath] = useState<string>(env.HOME);
    const [vfs, setVfs] = useState<VFSNode>(initialVFS);
    
    const [commandHistory, setCommandHistory] = useState<string[]>([]);
    const [historyIndex, setHistoryIndex] = useState<number>(-1);

    const print = useCallback((content: React.ReactNode | string, type: HistoryEntry['type'] = 'output') => {
        setHistory(prev => [...prev, { id: generateId(), type, content }]);
    }, []);

    const clear = useCallback(() => {
        setHistory([]);
    }, []);

    const execute = useCallback(async (cmd: string) => {
        setHistory(prev => [...prev, { 
            id: generateId(), 
            type: 'input', 
            content: cmd,
            path: currentPath
        }]);

        if (cmd.trim()) {
            setCommandHistory(prev => [...prev, cmd]);
            setHistoryIndex(-1);
        }

        await executeCommand(
            cmd, currentPath, vfs, setVfs, setCurrentPath, print, clear, env, setEnv, commandHistory
        );
    }, [currentPath, vfs, print, clear, env, commandHistory]);

    const navigateHistory = useCallback((direction: 'up' | 'down'): string | null => {
        if (commandHistory.length === 0) return null;

        let newIndex = historyIndex;
        if (direction === 'up') {
            newIndex = historyIndex === -1 ? commandHistory.length - 1 : Math.max(0, historyIndex - 1);
        } else {
            newIndex = historyIndex === -1 ? -1 : Math.min(commandHistory.length, historyIndex + 1);
        }

        setHistoryIndex(newIndex);

        if (newIndex === -1 || newIndex === commandHistory.length) {
            return '';
        }
        return commandHistory[newIndex];
    }, [commandHistory, historyIndex]);

    return {
        history,
        currentPath,
        env,
        vfs,
        execute,
        navigateHistory
    };
};
