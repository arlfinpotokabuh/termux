import React from 'react';
import { CommandContext } from '../types';
import { resolvePath, getNodeAtPath, cloneVFS, writeFile } from '../utils/vfs';

type CommandHandler = (ctx: CommandContext) => void | Promise<void>;

// Track boot time for uptime command
const BOOT_TIME = Date.now();

const commands: Record<string, CommandHandler> = {
    help: ({ print }) => {
        const helpText = `
======================================================================
        DAFTAR PERINTAH WAJIB DI TERMUX (WebTerm Edition)
======================================================================

[ 1. PEMELIHARAAN SISTEM & REPOSITORI ]
  apt update / upgrade  - Memperbarui daftar paket/aplikasi.
  pkg install <nama>    - Menginstal aplikasi baru.
  pkg uninstall <nama>  - Menghapus aplikasi.
  pkg list-installed    - Menampilkan aplikasi terinstal.
  clear                 - Membersihkan layar.
  exit                  - Keluar dari sesi.

[ 2. HAK AKSES & PENYIMPANAN HP ]
  termux-setup-storage  - Memberikan izin akses memori internal.

[ 3. NAVIGASI FOLDER (DIREKTORI) ]
  pwd                   - Melihat posisi folder saat ini.
  ls / ls -la           - Melihat daftar file dan folder.
  cd <folder> / cd ..   - Pindah folder / Naik 1 tingkat.
  cd ~ / cd /sdcard     - Ke folder home / memori internal.

[ 4. MANAJEMEN FILE & FOLDER ]
  mkdir <folder>        - Membuat folder baru.
  touch <file>          - Membuat file baru kosong.
  rm <file> / rm -rf    - Menghapus file / folder.
  cp <file> <tujuan>    - Menyalin file.
  mv <file> <tujuan>    - Memindah/mengubah nama file.

[ 5. INFORMASI STORAGE & SISTEM ]
  df -h / du -sh *      - Melihat sisa ruang / ukuran folder.
  free -h               - Melihat penggunaan RAM.
  uname -a / whoami     - Informasi sistem / user aktif.

[ 6. ALAT EDIT TEKS DI TERMINAL ]
  nano <file>           - Membuka/mengedit file teks (via Prompt).
  cat <file>            - Menampilkan isi file teks.

======================================================================
        TOOLS & PACKAGES WAJIB DI TERMUX (REKOMENDASI)
======================================================================

[ 1. ALAT PENGEMBANGAN & PEMROGRAMAN ]
  python, git, nodejs, clang, php

[ 2. UTALITAS JARINGAN & PENGUJIAN KEAMANAN ]
  curl, wget, nmap, openssh, net-tools

[ 3. EDITOR & MANAGEMENT FILE ]
  nano, vim, micro, mc, zip

[ 4. SYSTEM MONITORING & KUSTOMISASI ]
  htop, ncdu, neofetch, tmux, tsu

[ 5. DOWNLOADER & MULTIMEDIA ]
  ffmpeg, yt-dlp
======================================================================
        `;
        print(helpText);
    },

    clear: ({ clear }) => clear(),

    exit: ({ print }) => {
        print('logout');
        setTimeout(() => window.location.reload(), 1000);
    },

    'termux-setup-storage': ({ vfs, setVfs, env, print }) => {
        const newVfs = cloneVFS(vfs);
        
        // Create /sdcard at root
        if (!newVfs.children) newVfs.children = {};
        if (!newVfs.children['sdcard']) {
            newVfs.children['sdcard'] = { type: 'dir', name: 'sdcard', createdAt: Date.now(), children: {} };
        }
        
        // Create ~/storage symlink (mocked as dir)
        const homeNode = getNodeAtPath(newVfs, env.HOME);
        if (homeNode && homeNode.type === 'dir') {
            if (!homeNode.children) homeNode.children = {};
            if (!homeNode.children['storage']) {
                homeNode.children['storage'] = { type: 'dir', name: 'storage', createdAt: Date.now(), children: {} };
            }
        }
        
        setVfs(newVfs);
        print('Storage permission granted.\nSymlinks created:\n~/storage -> /sdcard\n/sdcard is now accessible.');
    },

    echo: ({ args, env, currentPath, vfs, setVfs, print }) => {
        // Check for basic redirection '>'
        const redirectIndex = args.indexOf('>');
        if (redirectIndex !== -1 && redirectIndex < args.length - 1) {
            const contentArgs = args.slice(0, redirectIndex);
            const fileName = args[redirectIndex + 1];
            const output = contentArgs.join(' ').replace(/\$([a-zA-Z_]+)/g, (_, key) => env[key] || '');

            const targetPath = resolvePath(currentPath, fileName);
            const newVfs = cloneVFS(vfs);
            if (writeFile(newVfs, targetPath, output)) {
                setVfs(newVfs);
            } else {
                print(`bash: ${fileName}: No such file or directory`, 'error');
            }
            return;
        }

        // Normal echo
        const output = args.join(' ').replace(/\$([a-zA-Z_]+)/g, (_, key) => env[key] || '');
        print(output);
    },

    pwd: ({ currentPath, print }) => print(currentPath),

    ls: ({ args, currentPath, vfs, print }) => {
        const showHidden = args.some(a => a.includes('a') && a.startsWith('-'));
        const longFormat = args.some(a => a.includes('l') && a.startsWith('-'));
        const targetArgs = args.filter(a => !a.startsWith('-'));
        
        const targetPath = targetArgs.length > 0 ? resolvePath(currentPath, targetArgs[0]) : currentPath;
        const node = getNodeAtPath(vfs, targetPath);

        if (!node) {
            print(`ls: cannot access '${targetPath}': No such file or directory`, 'error');
            return;
        }

        if (node.type === 'file') {
            if (longFormat) {
                const date = new Date(node.createdAt).toLocaleString('en-US', { month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' }).replace(',', '');
                print(`-rw-r--r-- 1 u0_a123 u0_a123 ${node.content?.length || 0} ${date} ${node.name}`);
            } else {
                print(node.name);
            }
            return;
        }

        if (node.children) {
            let entries = Object.values(node.children);
            if (!showHidden) {
                entries = entries.filter(e => !e.name.startsWith('.'));
            }
            
            entries.sort((a, b) => {
                if (a.type === b.type) return a.name.localeCompare(b.name);
                return a.type === 'dir' ? -1 : 1;
            });

            if (entries.length === 0) return;

            if (longFormat) {
                const output = entries.map(entry => {
                    const isDir = entry.type === 'dir';
                    const perms = isDir ? 'drwxr-xr-x' : '-rw-r--r--';
                    const size = isDir ? 4096 : (entry.content?.length || 0);
                    const date = new Date(entry.createdAt).toLocaleString('en-US', { month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit' }).replace(',', '');
                    const colorClass = isDir ? 'text-term-dir font-bold' : 'text-term-fg';
                    return `${perms} 1 u0_a123 u0_a123 ${size.toString().padStart(5, ' ')} ${date} <span class="${colorClass}">${entry.name}</span>`;
                }).join('\n');
                print({ __html: output } as any);
            } else {
                const output = entries.map(entry => {
                    const colorClass = entry.type === 'dir' ? 'text-term-dir font-bold' : 'text-term-fg';
                    return `<span class="${colorClass} mr-4">${entry.name}</span>`;
                }).join('');
                print({ __html: output } as any); 
            }
        }
    },

    cd: ({ args, currentPath, vfs, setCurrentPath, env, print }) => {
        const target = args.length === 0 ? env.HOME : args[0];
        const targetPath = resolvePath(currentPath, target);
        const node = getNodeAtPath(vfs, targetPath);

        if (!node) {
            print(`cd: ${target}: No such file or directory`, 'error');
        } else if (node.type !== 'dir') {
            print(`cd: ${target}: Not a directory`, 'error');
        } else {
            setCurrentPath(targetPath);
        }
    },

    mkdir: ({ args, currentPath, vfs, setVfs, print }) => {
        if (args.length === 0) return print('mkdir: missing operand', 'error');
        const newVfs = cloneVFS(vfs);
        let success = true;

        for (const dirName of args) {
            const targetPath = resolvePath(currentPath, dirName);
            const parentPath = resolvePath(targetPath, '..');
            const newDirName = targetPath.split('/').pop();

            if (!newDirName) continue;
            const parentNode = getNodeAtPath(newVfs, parentPath);

            if (!parentNode || parentNode.type !== 'dir') {
                print(`mkdir: cannot create directory '${dirName}': No such file or directory`, 'error');
                success = false; break;
            }
            if (parentNode.children && parentNode.children[newDirName]) {
                print(`mkdir: cannot create directory '${dirName}': File exists`, 'error');
                success = false; break;
            }

            if (!parentNode.children) parentNode.children = {};
            parentNode.children[newDirName] = { type: 'dir', name: newDirName, createdAt: Date.now(), children: {} };
        }
        if (success) setVfs(newVfs);
    },

    touch: ({ args, currentPath, vfs, setVfs, print }) => {
        if (args.length === 0) return print('touch: missing file operand', 'error');
        const newVfs = cloneVFS(vfs);
        let success = true;

        for (const fileName of args) {
            const targetPath = resolvePath(currentPath, fileName);
            const parentPath = resolvePath(targetPath, '..');
            const newFileName = targetPath.split('/').pop();

            if (!newFileName) continue;
            const parentNode = getNodeAtPath(newVfs, parentPath);

            if (!parentNode || parentNode.type !== 'dir') {
                print(`touch: cannot touch '${fileName}': No such file or directory`, 'error');
                success = false; break;
            }

            if (!parentNode.children) parentNode.children = {};
            if (!parentNode.children[newFileName]) {
                parentNode.children[newFileName] = { type: 'file', name: newFileName, content: '', createdAt: Date.now() };
            }
        }
        if (success) setVfs(newVfs);
    },

    cat: ({ args, currentPath, vfs, print }) => {
        if (args.length === 0) return print('cat: missing file operand', 'error');
        for (const fileName of args) {
            const node = getNodeAtPath(vfs, resolvePath(currentPath, fileName));
            if (!node) print(`cat: ${fileName}: No such file or directory`, 'error');
            else if (node.type === 'dir') print(`cat: ${fileName}: Is a directory`, 'error');
            else print(node.content || '');
        }
    },

    nano: ({ args, currentPath, vfs, setVfs, print }) => {
        if (args.length === 0) return print('nano: missing filename', 'error');
        const targetPath = resolvePath(currentPath, args[0]);
        const node = getNodeAtPath(vfs, targetPath);
        if (node && node.type === 'dir') return print(`nano: ${args[0]} is a directory`, 'error');

        const currentContent = node ? node.content : '';
        // Using window.prompt as a simple fallback for a TUI editor
        const newContent = window.prompt(`Nano Editor - ${args[0]}\n\nEdit your file content below:`, currentContent || '');

        if (newContent !== null) {
            const newVfs = cloneVFS(vfs);
            if (writeFile(newVfs, targetPath, newContent)) {
                setVfs(newVfs);
                print(`[ Wrote ${newContent.split('\n').length} lines to ${args[0]} ]`);
            } else {
                print(`nano: could not save ${args[0]}`, 'error');
            }
        } else {
            print('nano: editing canceled');
        }
    },
    
    vim: (ctx) => commands.nano(ctx),
    micro: (ctx) => commands.nano(ctx),

    rm: ({ args, currentPath, vfs, setVfs, print }) => {
        if (args.length === 0) return print('rm: missing operand', 'error');
        const newVfs = cloneVFS(vfs);
        let success = true;

        const isRecursive = args.includes('-r') || args.includes('-rf');
        const targets = args.filter(a => !a.startsWith('-'));

        for (const target of targets) {
            const targetPath = resolvePath(currentPath, target);
            if (targetPath === '/' || targetPath.startsWith('/data/data/com.termux/files/usr')) {
                print(`rm: cannot remove '${target}': Permission denied`, 'error');
                success = false; continue;
            }

            const parentPath = resolvePath(targetPath, '..');
            const targetName = targetPath.split('/').pop();
            if (!targetName) continue;

            const parentNode = getNodeAtPath(newVfs, parentPath);
            const targetNode = getNodeAtPath(newVfs, targetPath);

            if (!parentNode || !parentNode.children || !targetNode) {
                print(`rm: cannot remove '${target}': No such file or directory`, 'error');
                success = false; continue;
            }

            if (targetNode.type === 'dir' && !isRecursive) {
                print(`rm: cannot remove '${target}': Is a directory`, 'error');
                success = false; continue;
            }

            delete parentNode.children[targetName];
        }
        if (success) setVfs(newVfs);
    },

    cp: ({ args, currentPath, vfs, setVfs, print }) => {
        if (args.length < 2) return print('cp: missing file operand', 'error');
        const sourcePath = resolvePath(currentPath, args[0]);
        const destPath = resolvePath(currentPath, args[1]);
        
        const sourceNode = getNodeAtPath(vfs, sourcePath);
        if (!sourceNode) return print(`cp: cannot stat '${args[0]}': No such file or directory`, 'error');
        if (sourceNode.type === 'dir') return print(`cp: -r not specified; omitting directory '${args[0]}'`, 'error');

        const newVfs = cloneVFS(vfs);
        let finalDestPath = destPath;
        const destNode = getNodeAtPath(newVfs, destPath);
        
        if (destNode && destNode.type === 'dir') {
            finalDestPath = resolvePath(destPath, sourceNode.name);
        }

        if (writeFile(newVfs, finalDestPath, sourceNode.content || '')) {
            setVfs(newVfs);
        } else {
            print(`cp: cannot create regular file '${args[1]}': No such file or directory`, 'error');
        }
    },

    mv: ({ args, currentPath, vfs, setVfs, print }) => {
        if (args.length < 2) return print('mv: missing file operand', 'error');
        const sourcePath = resolvePath(currentPath, args[0]);
        const destPath = resolvePath(currentPath, args[1]);
        
        const sourceNode = getNodeAtPath(vfs, sourcePath);
        if (!sourceNode) return print(`mv: cannot stat '${args[0]}': No such file or directory`, 'error');

        const newVfs = cloneVFS(vfs);
        
        // Remove source
        const sourceParentPath = resolvePath(sourcePath, '..');
        const sourceName = sourcePath.split('/').pop()!;
        const sourceParentNode = getNodeAtPath(newVfs, sourceParentPath);
        if (sourceParentNode && sourceParentNode.children) {
            delete sourceParentNode.children[sourceName];
        }

        // Add to dest
        let finalDestPath = destPath;
        const destNode = getNodeAtPath(newVfs, destPath);
        if (destNode && destNode.type === 'dir') {
            finalDestPath = resolvePath(destPath, sourceNode.name);
        }

        const destParentPath = resolvePath(finalDestPath, '..');
        const destName = finalDestPath.split('/').pop()!;
        const destParentNode = getNodeAtPath(newVfs, destParentPath);

        if (destParentNode && destParentNode.type === 'dir') {
            if (!destParentNode.children) destParentNode.children = {};
            destParentNode.children[destName] = { ...sourceNode, name: destName };
            setVfs(newVfs);
        } else {
            print(`mv: cannot move to '${args[1]}': No such file or directory`, 'error');
        }
    },

    grep: ({ args, currentPath, vfs, print }) => {
        if (args.length < 2) return print('Usage: grep [PATTERN] [FILE]', 'error');
        const pattern = args[0];
        const fileName = args[1];
        const node = getNodeAtPath(vfs, resolvePath(currentPath, fileName));

        if (!node) return print(`grep: ${fileName}: No such file or directory`, 'error');
        if (node.type === 'dir') return print(`grep: ${fileName}: Is a directory`, 'error');

        const lines = (node.content || '').split('\n');
        const matches = lines.filter(line => line.includes(pattern));
        if (matches.length > 0) {
            // Highlight match
            const highlighted = matches.map(line => 
                line.split(pattern).join(`<span class="text-term-error font-bold">${pattern}</span>`)
            ).join('\n');
            print({ __html: highlighted } as any);
        }
    },

    whoami: ({ env, print }) => print(env.USER),
    date: ({ print }) => print(new Date().toString()),
    uname: ({ args, print }) => {
        if (args.includes('-a')) print('Linux localhost 4.14.113-perf+ #1 SMP PREEMPT aarch64 Android');
        else print('Linux');
    },

    env: ({ env, print }) => {
        const output = Object.entries(env).map(([k, v]) => `${k}=${v}`).join('\n');
        print(output);
    },

    export: ({ args, env, setEnv, print }) => {
        if (args.length === 0) return;
        const [key, ...valParts] = args[0].split('=');
        if (key && valParts.length > 0) {
            setEnv({ ...env, [key]: valParts.join('=') });
        }
    },

    history: ({ commandHistory, print }) => {
        const output = commandHistory.map((cmd, i) => `  ${i + 1}  ${cmd}`).join('\n');
        print(output);
    },

    neofetch: ({ env, print }) => {
        const ascii = `
<span class="text-term-prompt">       _    _</span>
<span class="text-term-prompt">      | |  | |</span>
<span class="text-term-prompt">      | |__| |</span>
<span class="text-term-prompt">      |  __  |</span>
<span class="text-term-prompt">      | |  | |</span>
<span class="text-term-prompt">      |_|  |_|</span>
        `;
        const info = `
<span class="text-term-prompt font-bold">${env.USER}@localhost</span>
-----------------
<span class="text-term-prompt font-bold">OS</span>: Termux (WebTerm) aarch64
<span class="text-term-prompt font-bold">Host</span>: HTML5 Browser
<span class="text-term-prompt font-bold">Kernel</span>: 4.14.113-perf+
<span class="text-term-prompt font-bold">Uptime</span>: 1 min
<span class="text-term-prompt font-bold">Packages</span>: 42 (dpkg)
<span class="text-term-prompt font-bold">Shell</span>: ${env.SHELL}
<span class="text-term-prompt font-bold">Terminal</span>: WebTerm
<span class="text-term-prompt font-bold">Memory</span>: 1024MiB / 4096MiB
        `;
        
        const html = `<div class="flex gap-8 items-center"><div>${ascii}</div><div>${info}</div></div>`;
        print({ __html: html } as any);
    },

    lscpu: ({ print }) => {
        const cores = navigator.hardwareConcurrency || 8;
        const output = `Architecture:            aarch64
CPU op-mode(s):          32-bit, 64-bit
Byte Order:              Little Endian
CPU(s):                  ${cores}
On-line CPU(s) list:     0-${cores - 1}
Thread(s) per core:      1
Core(s) per socket:      ${cores > 4 ? 4 : cores}
Socket(s):               ${Math.ceil(cores / 4)}
Vendor ID:               ARM
Model:                   1
Stepping:                r1p0
CPU max MHz:             2841.6000
CPU min MHz:             300.0000
BogoMIPS:                38.40`;
        print(output);
    },

    free: ({ args, print }) => {
        // Mock memory based on deviceMemory if available, else 4GB
        const totalMemGB = (navigator as any).deviceMemory || 4;
        const totalMemKB = totalMemGB * 1024 * 1024;
        const usedMemKB = Math.floor(totalMemKB * 0.4); // Mock 40% used
        const freeMemKB = Math.floor(totalMemKB * 0.2); // Mock 20% free
        const buffCacheKB = totalMemKB - usedMemKB - freeMemKB;
        const availableKB = freeMemKB + Math.floor(buffCacheKB * 0.5);
        
        const isHuman = args.includes('-h');
        
        if (isHuman) {
            print(`              total        used        free      shared  buff/cache   available
Mem:           ${totalMemGB}.0G        ${(usedMemKB/1024/1024).toFixed(1)}G        ${(freeMemKB/1024/1024).toFixed(1)}G          0B        ${(buffCacheKB/1024/1024).toFixed(1)}G        ${(availableKB/1024/1024).toFixed(1)}G
Swap:          2.0G          0B        2.0G`);
        } else {
            print(`               total        used        free      shared  buff/cache   available
Mem:         ${totalMemKB}     ${usedMemKB}      ${freeMemKB}           0     ${buffCacheKB}     ${availableKB}
Swap:        2097152           0     2097152`);
        }
    },

    df: ({ args, print }) => {
        const isHuman = args.includes('-h');
        if (isHuman) {
            print(`Filesystem      Size  Used Avail Use% Mounted on
/dev/root       2.0G  1.1G  900M  56% /
tmpfs           1.9G  420K  1.9G   1% /dev
/dev/block/sda1  62G   12G   50G  19% /data`);
        } else {
            print(`Filesystem     1K-blocks    Used Available Use% Mounted on
/dev/root        2031440 1123400    908040  56% /
tmpfs            1920060     420   1919640   1% /dev
/dev/block/sda1 64000000 12000000 52000000  19% /data`);
        }
    },

    du: ({ args, currentPath, vfs, print }) => {
        const targetArgs = args.filter(a => !a.startsWith('-'));
        const target = targetArgs.length > 0 ? targetArgs[0] : '.';
        
        if (target === '*') {
            const node = getNodeAtPath(vfs, currentPath);
            if (node && node.children) {
                const output = Object.values(node.children).map(child => {
                    const size = child.type === 'dir' ? '4.0K' : `${Math.max(1, Math.ceil((child.content?.length || 0) / 1024))}K`;
                    return `${size}\t${child.name}`;
                }).join('\n');
                print(output || '0\t.');
            } else {
                print('0\t.');
            }
        } else {
            print(`4.0K\t${target}`);
        }
    },

    uptime: ({ print }) => {
        const now = Date.now();
        const diffSeconds = Math.floor((now - BOOT_TIME) / 1000);
        const mins = Math.floor(diffSeconds / 60);
        const hours = Math.floor(mins / 60);
        const displayMins = mins % 60;
        
        const timeStr = new Date().toLocaleTimeString('en-US', { hour12: false });
        const upStr = hours > 0 ? `${hours}:${displayMins.toString().padStart(2, '0')}` : `${mins} min`;
        
        print(` ${timeStr} up ${upStr},  1 user,  load average: 0.00, 0.01, 0.05`);
    },

    ps: ({ print }) => {
        print(`  PID TTY          TIME CMD
18234 pts/0    00:00:00 bash
18285 pts/0    00:00:00 ps`);
    },

    top: ({ print }) => {
        const totalMemGB = (navigator as any).deviceMemory || 4;
        const totalMemMB = totalMemGB * 1024;
        const usedMemMB = (totalMemMB * 0.4).toFixed(1);
        const freeMemMB = (totalMemMB * 0.2).toFixed(1);
        const buffCacheMB = (totalMemMB * 0.4).toFixed(1);

        print(`Tasks:   4 total,   1 running,   3 sleeping,   0 stopped,   0 zombie
%Cpu(s):  2.5 us,  1.0 sy,  0.0 ni, 96.0 id,  0.0 wa,  0.0 hi,  0.5 si,  0.0 st
MiB Mem :   ${totalMemMB.toFixed(1)} total,    ${freeMemMB} free,   ${usedMemMB} used,   ${buffCacheMB} buff/cache
MiB Swap:   2097.1 total,   2097.1 free,      0.0 used.   ${(parseFloat(freeMemMB) + parseFloat(buffCacheMB)*0.5).toFixed(1)} avail Mem

  PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    1 root      20   0   10240   2048   1024 S   0.0   0.1   0:01.23 init
18234 u0_a123   20   0   20480   4096   2048 S   0.0   0.1   0:00.45 bash
18286 u0_a123   20   0   15360   3072   1536 R   2.5   0.1   0:00.01 top`);
    },
    
    htop: (ctx) => commands.top(ctx),

    ifconfig: ({ print }) => {
        print(`wlan0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500
        inet 192.168.1.101  netmask 255.255.255.0  broadcast 192.168.1.255
        inet6 fe80::1a2b:3c4d:5e6f:7g8h  prefixlen 64  scopeid 0x20<link>
        ether 00:11:22:33:44:55  txqueuelen 1000  (Ethernet)
        RX packets 123456  bytes 123456789 (117.7 MiB)
        TX packets 654321  bytes 987654321 (941.9 MiB)

lo: flags=73<UP,LOOPBACK,RUNNING>  mtu 65536
        inet 127.0.0.1  netmask 255.0.0.0
        inet6 ::1  prefixlen 128  scopeid 0x10<host>
        loop  txqueuelen 1000  (Local Loopback)
        RX packets 123  bytes 12345 (12.0 KiB)
        TX packets 123  bytes 12345 (12.0 KiB)`);
    },
    
    ip: ({ args, print }) => {
        if (args[0] === 'a' || args[0] === 'addr') {
            print(`1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host 
       valid_lft forever preferred_lft forever
2: wlan0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc mq state UP group default qlen 1000
    link/ether 00:11:22:33:44:55 brd ff:ff:ff:ff:ff:ff
    inet 192.168.1.101/24 brd 192.168.1.255 scope global wlan0
       valid_lft forever preferred_lft forever
    inet6 fe80::1a2b:3c4d:5e6f:7g8h/64 scope link 
       valid_lft forever preferred_lft forever`);
        } else {
            print('Usage: ip [ OPTIONS ] OBJECT { COMMAND | help }\n       ip addr show');
        }
    },

    pkg: ({ args, print }) => {
        if (args.length === 0) return print('Usage: pkg [install|uninstall|update|upgrade|list-installed|search] [package]', 'error');
        const action = args[0];
        const pkgName = args[1] || 'packages';

        if (action === 'update' || action === 'upgrade') {
            print('Hit:1 https://packages.termux.dev/apt/termux-main stable InRelease\nReading package lists... Done\nBuilding dependency tree... Done\nAll packages are up to date.');
        } else if (action === 'install') {
            if (!args[1]) return print('pkg: missing package name', 'error');
            print(`Reading package lists... Done\nBuilding dependency tree... Done\nThe following NEW packages will be installed:\n  ${pkgName}\n0 upgraded, 1 newly installed, 0 to remove.\nNeed to get 1024 kB of archives.\nAfter this operation, 3072 kB of additional disk space will be used.\nGet:1 https://packages.termux.dev/apt/termux-main stable/main aarch64 ${pkgName} [1024 kB]\nFetched 1024 kB in 1s (1024 kB/s)\nSelecting previously unselected package ${pkgName}.\nPreparing to unpack .../${pkgName}.deb ...\nUnpacking ${pkgName} ...\nSetting up ${pkgName} ...`);
        } else if (action === 'uninstall') {
            if (!args[1]) return print('pkg: missing package name', 'error');
            print(`Reading package lists... Done\nBuilding dependency tree... Done\nThe following packages will be REMOVED:\n  ${pkgName}\n0 upgraded, 0 newly installed, 1 to remove.\nRemoving ${pkgName} ...`);
        } else if (action === 'list-installed') {
            print('bash\nclang\ncoreutils\ncurl\ndpkg\nffmpeg\ngit\ngrep\nhtop\nmicro\nnano\nncdu\nneofetch\nnet-tools\nnmap\nnodejs\nopenssh\nphp\npython\ntermux-tools\ntmux\ntsu\nvim\nwget\nyt-dlp\nzip');
        } else if (action === 'search') {
            if (!args[1]) return print('pkg: missing package name', 'error');
            print(`Sorting...\nFull Text Search...\n${pkgName}/stable 1.0.0 aarch64\n  A mocked package for ${pkgName}`);
        } else {
            print(`pkg: unknown command '${action}'`, 'error');
        }
    },

    apt: (ctx) => commands.pkg(ctx), // Alias apt to pkg

    ping: ({ args, print }) => {
        if (args.length === 0) return print('Usage: ping [destination]', 'error');
        const host = args[0];
        print(`PING ${host} (192.168.1.1) 56(84) bytes of data.\n64 bytes from 192.168.1.1: icmp_seq=1 ttl=64 time=12.4 ms\n64 bytes from 192.168.1.1: icmp_seq=2 ttl=64 time=14.2 ms\n64 bytes from 192.168.1.1: icmp_seq=3 ttl=64 time=11.8 ms\n^C\n--- ${host} ping statistics ---\n3 packets transmitted, 3 received, 0% packet loss, time 2003ms`);
    },

    curl: async ({ args, print }) => {
        if (args.length === 0) return print('curl: try \'curl --help\' or \'curl --manual\' for more information', 'error');
        const url = args.find(a => a.startsWith('http'));
        if (!url) return print('curl: no URL specified', 'error');

        print(`Fetching ${url}...`);
        try {
            const res = await fetch(url);
            const text = await res.text();
            // Truncate if too long to prevent browser freeze
            print(text.length > 2000 ? text.substring(0, 2000) + '\n...[TRUNCATED]' : text);
        } catch (err: any) {
            print(`curl: (6) Could not resolve host: ${url} (or CORS blocked the request)`, 'error');
        }
    },
    
    wget: ({ args, print }) => {
        if (args.length === 0) return print("wget: missing URL\nUsage: wget [OPTION]... [URL]...\n\nTry `wget --help' for more options.", "error");
        const url = args.find(a => a.startsWith('http')) || args[0];
        print(`--2023-10-27 10:00:00--  ${url}\nResolving host... 93.184.216.34\nConnecting to 93.184.216.34:443... connected.\nHTTP request sent, awaiting response... 200 OK\nLength: 1256 (1.2K) [text/html]\nSaving to: 'index.html'\n\n     0K .                                                     100% 1.23M=0.001s\n\n2023-10-27 10:00:00 (1.23 MB/s) - 'index.html' saved [1256/1256]`);
    },

    python: ({ args, print }) => {
        if (args.length === 0) {
            print("Python 3.11.4 (main, Jun  9 2023, 07:59:55) [Clang 14.0.6 ] on linux\nType \"help\", \"copyright\", \"credits\" or \"license\" for more information.\n>>> (REPL not fully supported in WebTerm, press Ctrl+C to exit)");
        } else {
            print(`python: can't open file '${args[0]}': [Errno 2] No such file or directory`);
        }
    },
    
    git: ({ args, print }) => {
        if (args.length === 0) return print("usage: git [--version] [--help] [-C <path>] [-c <name>=<value>]\n           [--exec-path[=<path>]] [--html-path] [--man-path] [--info-path]\n           [-p | --paginate | -P | --no-pager] [--no-replace-objects] [--bare]\n           [--git-dir=<path>] [--work-tree=<path>] [--namespace=<name>]\n           [--super-prefix=<path>] [--config-env=<name>=<envvar>]\n           <command> [<args>]");
        if (args[0] === 'clone') print(`Cloning into '${args[1]?.split('/').pop()?.replace('.git', '') || 'repo'}'...\nremote: Enumerating objects: 100, done.\nremote: Counting objects: 100% (100/100), done.\nremote: Compressing objects: 100% (80/80), done.\nReceiving objects: 100% (100/100), 1.23 MiB | 2.45 MiB/s, done.\nResolving deltas: 100% (20/20), done.`);
        else print(`git version 2.41.0`);
    },
    
    node: ({ args, print }) => print(args.includes('--version') || args.includes('-v') ? 'v18.16.0' : 'Welcome to Node.js v18.16.0.\nType ".help" for more information.\n> (REPL not fully supported)'),
    
    npm: ({ args, print }) => print(args.includes('--version') || args.includes('-v') ? '9.5.1' : 'npm <command>\n\nUsage:\n\nnpm install        install all the dependencies in your project\nnpm install <foo>  add the <foo> dependency to your project'),
    
    zip: ({ args, print }) => {
        if (args.length < 2) return print("Copyright (c) 1990-2008 Info-ZIP - Type 'zip \"-L\"' for software license.\nZip 3.0 (July 5th 2008). Usage:\nzip [-options] [-b path] [-t mmddyyyy] [-n suffixes] [zipfile list] [-xi list]", "error");
        print(`  adding: ${args[1]} (stored 0%)`);
    },

    cowsay: ({ args, print }) => {
        const text = args.length > 0 ? args.join(' ') : 'Moo';
        const border = '-'.repeat(text.length + 2);
        const cow = `
 ${border}
< ${text} >
 ${border}
        \\   ^__^
         \\  (oo)\\_______
            (__)\\       )\\/\\
                ||----w |
                ||     ||
        `;
        print(cow);
    },

    '^c': () => {}, // Handled by App.tsx, just prevents "command not found"
    '^z': ({ print }) => print('[1]+  Stopped                 process')
};

export const executeCommand = async (
    rawInput: string,
    currentPath: string,
    vfs: VFSNode,
    setVfs: React.Dispatch<React.SetStateAction<VFSNode>>,
    setCurrentPath: React.Dispatch<React.SetStateAction<string>>,
    print: (content: React.ReactNode | string, type?: HistoryEntry['type']) => void,
    clear: () => void,
    env: Record<string, string>,
    setEnv: React.Dispatch<React.SetStateAction<Record<string, string>>>,
    commandHistory: string[]
) => {
    const trimmed = rawInput.trim();
    if (!trimmed) return;

    // Basic parsing: split by space, handle quotes roughly
    const parts = trimmed.match(/(?:[^\s"']+|['"][^'"]*["'])+/g) || [];
    const cmd = parts[0].toLowerCase();
    const args = parts.slice(1).map(arg => arg.replace(/^['"](.*)['"]$/, '$1'));

    const handler = commands[cmd];

    if (handler) {
        try {
            await handler({
                args, rawCommand: trimmed, currentPath, vfs, setVfs, setCurrentPath, print, clear, env, setEnv, commandHistory
            });
        } catch (err: any) {
            print(`Error executing ${cmd}: ${err.message}`, 'error');
        }
    } else {
        print(`bash: ${cmd}: command not found`, 'error');
    }
};
